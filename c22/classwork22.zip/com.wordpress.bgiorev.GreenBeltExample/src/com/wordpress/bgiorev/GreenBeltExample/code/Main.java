package com.wordpress.bgiorev.GreenBeltExample.code;

import java.util.Scanner;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		int number = in.nextInt();
		double x = in.nextDouble();
		double y = in.nextDouble();
		Car c = new Car(number, x, y);
		try{
			c.load(10000);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		
		vehicleList.add(c);
		
		number = in.nextInt();
		x = in.nextDouble();
		y = in.nextDouble();
		Truck t = new Truck(number, x, y);
		try {
			t.load(10000);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		vehicleList.add(t);
		
		c.print(vehicleList);
		in.close();
	}

}
