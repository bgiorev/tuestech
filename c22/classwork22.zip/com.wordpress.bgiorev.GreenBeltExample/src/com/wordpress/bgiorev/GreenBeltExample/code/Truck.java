package com.wordpress.bgiorev.GreenBeltExample.code;

public class Truck extends Vehicle{
	public Truck(int number) {
		super(number);
	}
	
	public Truck(int number, double x, double y) {
		super(number, x, y);
	}
	
	public void load(double weight) throws Exception {
		if(weight > 20000) {
			
		} else {
			super.load(weight);
		}
	}
}
