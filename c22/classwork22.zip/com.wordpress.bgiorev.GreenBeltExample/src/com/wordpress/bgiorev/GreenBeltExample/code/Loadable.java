package com.wordpress.bgiorev.GreenBeltExample.code;

public interface Loadable {
	public abstract void load(double weight) throws Exception;
	public abstract double getLoad();
}
