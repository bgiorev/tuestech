package com.wordpress.bgiorev.GreenBeltExample.code;

public class Car extends Vehicle{
	public Car(int number){
		super(number);
	}
	
	public Car(int number, double x, double y) {
		super(number, x, y);
	}
	
	public void load(double weight) throws Exception {
		if (weight > 1000) {
			throw new Exception("This is too heavy for a car");
		}else{
			super.load(weight);
		}
	}
	
}
