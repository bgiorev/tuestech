package com.wordpress.bgiorev.GreenBeltExample.code;

import java.util.ArrayList;

public abstract class Vehicle implements Loadable{
	private int number;
	private double x,y, weight;
	
	public Vehicle(int number) {
		this.number = number;
	}
	
	public Vehicle(int number, double x, double y) {
		this.number = number;
		this.x = x;
		this.y = y;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public void print(ArrayList<Vehicle> vehicleList) {
		for(Vehicle v : vehicleList){
			System.out.print(v.getNumber() + " ");
			System.out.print(v.getX() + " ");
			System.out.print(v.getY() + " ");
			System.out.println(v.getLoad());
		}
	}
	
	public void load(double weight) throws Exception{
		this.weight = weight;
	}
	
	public double getLoad() {
		return weight;
	}
}
