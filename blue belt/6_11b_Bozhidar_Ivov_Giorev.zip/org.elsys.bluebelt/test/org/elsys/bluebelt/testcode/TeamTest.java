package org.elsys.bluebelt.testcode;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TeamTest {
	private Team team;
	
	@Before
	public void setUp(){
		team = new Team();
	}
	
	
	@Test
	public void testAddMember() {
		Member m1 = new Member("Ivan", 20, "Male");
		team.addMember(m1);
		
		Member m2 = new Member("Ivana", 21, "Female");
		team.addMember(m2);
		
		assertEquals(2, team.getNumberOfMembers());
	}
	
	@Test
	public void testRemoveMember() {
		Member m1 = new Member("Ivan", 20, "Male");
		team.addMember(m1);
		
		Member m2 = new Member("Ivana", 21, "Female");
		team.addMember(m2);
		
		assertEquals(2, team.getNumberOfMembers());
		
		team.removeMember(m1);
		assertEquals(1, team.getNumberOfMembers());
	}
	
	@Test
	public void testGetAverageAge() {
		Member m1 = new Member("Ivan", 10, "Male");
		team.addMember(m1);
		
		Member m2 = new Member("Ivana", 20, "Female");
		team.addMember(m2);
		
		assertEquals(15, team.getAverageAge());
	}
	
	@Test
	public void testContainsMemberWithName() {
		Member m1 = new Member("Ivan", 10, "Male");
		team.addMember(m1);
		
		Member m2 = new Member("Ivana", 20, "Female");
		team.addMember(m2);
		
		assertTrue(team.containsMemberWithName("Ivan"));
	}
	
	@Test
	public void testSortedByGenderAndName() {
		Member m1 = new Member("Ivan", 10, "Male");
		team.addMember(m1);
		
		Member m2 = new Member("Ivana", 20, "Female");
		team.addMember(m2);
		
		Member m3 = new Member("Alex", 17, "Male");
		team.addMember(m3);
		
		Member m4 = new Member("Iva", 25, "Female");
		team.addMember(m4);
		
		team.sortedByGenderAndAge();
		
		assertEquals("Female", team.getMember(0).getGender());
		assertEquals("Male", team.getMember(3).getGender());
	}
}
