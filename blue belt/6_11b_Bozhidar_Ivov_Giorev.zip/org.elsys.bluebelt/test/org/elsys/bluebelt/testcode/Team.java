package org.elsys.bluebelt.testcode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Team {
	private List<Member> memberList;
	private int members;
	
	public Team() {
		memberList = new ArrayList<Member>();
		members = 0;
	}
	
	public void addMember(Member m) {
		memberList.add(m);
		members++;
	}
	
	public void removeMember(Member m) {
		memberList.remove(m);
		members--;
	}
	
	public int getAverageAge() {
		int age = 0;
		for(Member m : memberList) {
			age += m.getAge();
		}
		age = age/members;
		return age;
	}
	
	public boolean containsMemberWithName(String name) {
		for(Member m : memberList) {
			if(m.getName().equals(name)) {
				return true;
			}
		}
		return false;
	}

	public int getNumberOfMembers() {
		return members;
	}
	
	public Member getMember(int index) {
		return memberList.get(index);
	}
	
	public void sortedByGenderAndAge() {
		List<Member> femaleList = new ArrayList<Member>();
		List<Member> maleList = new ArrayList<Member>();
		for(Member m : memberList) {
			if(m.getGender().equals("Female")){
				femaleList.add(m);
			}else{
				maleList.add(m);
			}
		}
		
		Comparator comparator = new Comparator<Member>() {

			@Override
			public int compare(Member m1, Member m2) {
				return m1.getAge() - m2.getAge();
			}
			
		};
		
		Collections.sort(femaleList, comparator);
		Collections.sort(maleList, comparator);
		memberList.clear();
		memberList.addAll(femaleList);
		memberList.addAll(maleList);
	}
	
}
