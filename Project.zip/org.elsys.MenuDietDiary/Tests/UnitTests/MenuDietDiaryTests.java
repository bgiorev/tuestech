package UnitTests;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import Diary.*;

import org.junit.Before;
import org.junit.Test;

public class MenuDietDiaryTests {
	private Diary d;
	@Before
	public void setUp(){
	 d=new Diary();
	}
	
	@Test
	public void testGetAll() throws ClassNotFoundException {
		assertEquals(d.getAllProducts()[0],"�������-����� �����");
	}
	
	@Test
	public void testSearch() throws ClassNotFoundException{
		Meal m = d.searchMeal("�������-����� �����",100);
		assertEquals(m.getName(),"�������-����� �����");
		assertEquals(m.getCalories(),1.22,0.00);
	}
	
	@Test
	public void testSave() throws ClassNotFoundException{
		Class.forName("org.sqlite.JDBC");
		ResultSet rs;
		Connection con=null;
		int mealId=0;
		int dayId=0;
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String today = dateFormat.format(date);
		try {
			con=DriverManager.getConnection("jdbc:sqlite:savedMeals.db");
			Statement statement = con.createStatement();
			Meal m = new Meal("test", 0, 0, 0, 0);
			d.searchMeal(m.getName(), 100);
			rs=statement.executeQuery("select * from meals where name like "+"'"+m.getName()+"'");
			if(rs.next()){
				mealId=rs.getInt("id");
			}
			rs=statement.executeQuery("select * from days where date like "+"'"+today+"'");
			if(rs.next()){
				dayId=rs.getInt("id");
			}
			if(mealId!=0 && dayId!=0)
				rs=statement.executeQuery("select * from linkingTable where mealsID="+"'"+mealId+"'"+" and daysID="+"'"+dayId+"'");
			assertTrue(rs.next());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
