package com.wordpress.bgiorev.homework16.code;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManyToOneRelation<O, M> {
	private Map<O, List<M>> connections;
	
	public ManyToOneRelation() {
		connections = new HashMap<O, List<M>>();
	}
	
	public void connect(O source, M target) {
		disconnectTarget(target);
		List<M> targets = connections.get(source);
		if(targets == null) {
			targets = new ArrayList<M>();
		}
		targets.add(target);
		connections.put(source, targets);
		
	}
	
	public List<M> getTargets(O source) {
		return connections.get(source);
	}

	private void disconnect(O source, M target) {
		List<M> targets = connections.get(source);
		targets.remove(target);
		if(targets.size() == 0) {
			disconnectSource(source);
		}
	}
	
	private O getSource(M target) {
		for(Map.Entry<O, List<M>> entry: connections.entrySet()) {
			for(M t : entry.getValue()) {
				if(t.equals(target)) {
					return entry.getKey();
				}
			}
		}
		return null;
	}

	public void disconnectSource(O source) {
		connections.remove(source);
	}

	public void disconnectTarget(M target) {
		O oldSource = getSource(target);
		if(oldSource != null) {
			disconnect(oldSource, target);
		}
	}

	public boolean containsSource(O source) {
		return connections.containsKey(source);
	}

	public boolean containsTarget(M target) {
		return getSource(target) != null;
	}
}