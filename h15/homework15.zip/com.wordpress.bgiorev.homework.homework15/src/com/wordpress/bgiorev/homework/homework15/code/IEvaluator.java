package com.wordpress.bgiorev.homework.homework15.code;

public interface IEvaluator {
	void add(double d);
	
	Double evaluate();
}
