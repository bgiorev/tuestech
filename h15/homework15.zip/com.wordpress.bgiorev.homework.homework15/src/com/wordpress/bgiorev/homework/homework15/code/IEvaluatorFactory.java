package com.wordpress.bgiorev.homework.homework15.code;

public interface IEvaluatorFactory {
	public IEvaluators createSumEvaluator();
	
	public IEvaluators createPowerOnEvaluator();
	
	public IEvaluators createPowerOnEvaluator(int power);
	
	public IEvaluators createFibonachiEvaluator();
}
