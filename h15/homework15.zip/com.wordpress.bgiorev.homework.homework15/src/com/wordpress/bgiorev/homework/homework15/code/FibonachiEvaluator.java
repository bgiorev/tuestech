package com.wordpress.bgiorev.homework.homework15.code;

public class FibonachiEvaluator extends IEvaluators{
	public Double evaluate() {
		double result = 0;
		for (Double d : getEvaluatorList()) {
			result += d;
		}
		double fib = 1, prev = 0;
		int i = 1;
		for (i = 1; fib <= result; i+=fib - prev) {
			fib += prev;
			prev = i;
		}
		if (Math.abs(fib - result) < Math.abs(prev - result)) {
			return fib;
		}else{
			return prev;
		}
		
	}
}
