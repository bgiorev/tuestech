package org.elsys.ballcontainer.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BallContainerTest {
	private BallContainer bc;
	
	@Before
	public void setUp() {
		bc = new BallContainer();
		Ball b = new Ball(1, "One", "Blue");
		bc.add(b);
	}
	
	@Test
	public void testAdd() {
		Ball b1 = new Ball(3, "Three", "Red");
		bc.add(b1);
		assertEquals(6, bc.getCapacity());
	}
	
	@Test
	public void testRemove() {
		Ball b1 = new Ball(1, "Two", "Orange");
		bc.add(b1);
		bc.remove(b1);
		assertEquals(9, bc.getCapacity());
	}
	
	@Test
	public void testContains() {
		Ball b1 = new Ball(1, "Two", "Orange");
		bc.add(b1);
		assertTrue(bc.contains(b1));
	}
	
	@Test
	public void testFree() {
		bc.free();
		assertEquals(10, bc.getCapacity());
	}
	
	@Test
	public void testCapacity() {
		assertEquals(9, bc.getCapacity());
	}
	
	@Test
	public void testFilled() {
		assertEquals(1, bc.getFilled());
	}
	
	@Test
	public void testGetFromSmallest() {
		Ball b1 = new Ball(3, "Three", "Red");
		bc.add(b1);
		Ball b2 = new Ball(2, "Two", "Yellow");
		bc.add(b2);
		bc.getFromSmallest();
		assertEquals(1, bc.getBall(0).getSize());
		assertEquals(2, bc.getBall(1).getSize());
		assertEquals(3, bc.getBall(2).getSize());
		
	}

	

}
