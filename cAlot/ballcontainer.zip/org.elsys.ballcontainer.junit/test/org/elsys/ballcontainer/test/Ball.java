package org.elsys.ballcontainer.test;

public class Ball {
	private int size;
	private String name;
	private String color;
	
	public Ball(int size, String name, String color) {
		super();
		this.size = size;
		this.name = name;
		this.color = color;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
}
