package org.elsys.ballcontainer.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BallContainer {
	private int filled = 10;
	private List<Ball> ballContainer = new ArrayList<Ball>(filled);
	private int capacity;
	
	public BallContainer() {
		capacity = 10;
	}
	
	public void add(Ball b) {
		ballContainer.add(b);
		capacity -= b.getSize();
	}
	
	public void remove(Ball b) {
		if(ballContainer.contains(b)) {
			ballContainer.remove(b);
			capacity += b.getSize();	
		}
	}
	
	public boolean contains(Ball b) {
		return ballContainer.contains(b);
	}
	
	public Ball getBall(int index) {
		Ball b = ballContainer.get(index);
		return b;
	}
	
	public void free() {
		ballContainer.clear();
		capacity = 10;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public int getFilled() {
		return 10-capacity;
	}
	
	
	
	public void getFromSmallest() {
		Comparator comparator = new Comparator<Ball>() {

			@Override
			public int compare(Ball b, Ball b1) {
				return b.getSize() - b1.getSize();		
			}
		};
		Collections.sort(ballContainer, comparator);
	}
}
