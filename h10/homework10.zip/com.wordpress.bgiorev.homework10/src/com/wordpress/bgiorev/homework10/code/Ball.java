/*
 * 	Технологично училище "Електронни системи"
 * www.elsys-bg.org
 * 11Б клас
 * Божидар ивов Гьорев
 * Номер 6
 * Задача - да се направи програма, която да слага топчета в кутия
 * */
package com.wordpress.bgiorev.homework10.code;

public class Ball {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
